drop database alteryx
drop table "All"
drop table dis1
drop table Fact

create database schema0

CREATE TABLE dis1 (
ADDRESS     nvarchar(255) PRIMARY KEY,
ENROLLMENT  INT,
FT_TEACHER  INT
);

CREATE TABLE dis2 (
OBJECTID     int PRIMARY KEY,
NAME        nvarchar(255),
LEVEL_      INT
);

CREATE TABLE Fact (
FID         INT  PRIMARY KEY ,
OBJECTID    INT,
ADDRESS     nvarchar(255),
CITY        nvarchar(255),
STATE       nvarchar(255),
POPULATION  INT,
COUNTY      nvarchar(255),
COUNTYFIPS  nvarchar(255),
SOURCE      nvarchar(255),
SOURCEDATE  nvarchar(255),
START_GRAD  INT,
END_GRADE   INT,
);
